function msg(){  
 alert("Hello JavaScript");  
}  
function a(){
	alert("This is A function");  
}